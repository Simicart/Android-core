package com.simicart.core.base.helper;

public class BackHelper extends SimiHelper {
	protected boolean isBack;

	public void setBack(boolean isBack) {
		this.isBack = isBack;
	}

	public boolean getIsBack() {
		return this.isBack;
	}
}
