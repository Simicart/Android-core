package com.simicart.core.base.network.request;

public interface SimiNetwork {

	public SimiNetworkResponse performRequest(SimiRequest request);
}
