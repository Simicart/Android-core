package com.simicart.core.catalog.filter.common;

public class FilterConstant {

	public static String TITLE = "title";
	public static String VALUE = "value";
	public static String ATTRIBUTE = "attribute";
	public static String FILTER = "filter";
	public static String LAYEREDNAVIGATION = "layerednavigation";
	public static String LABEL = "label";
	public static String LAYER_FILTER = "layer_filter";
	public static String LAYER_STATE = "layer_state";
}
