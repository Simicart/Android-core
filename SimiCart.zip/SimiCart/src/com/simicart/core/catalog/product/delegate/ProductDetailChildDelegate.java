package com.simicart.core.catalog.product.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface ProductDetailChildDelegate extends SimiDelegate{
	
	public void updateIndicator();

}
