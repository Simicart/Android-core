package com.simicart.core.catalog.category.fragment;

public class AllCategoryFragment extends CategoryFragment {

	public AllCategoryFragment() {
		super();
	}

	public static AllCategoryFragment newInstance(String name, String id) {
		AllCategoryFragment fragment = new AllCategoryFragment();
		return fragment;
	}

}
