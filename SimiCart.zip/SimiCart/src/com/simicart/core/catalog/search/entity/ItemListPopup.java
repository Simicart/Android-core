package com.simicart.core.catalog.search.entity;


public class ItemListPopup {

	private String name;
	private boolean checkSearch;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCheckSearch(boolean checkSearch) {
		this.checkSearch = checkSearch;
	}

	public boolean isCheckSearch() {
		return checkSearch;
	}

}
